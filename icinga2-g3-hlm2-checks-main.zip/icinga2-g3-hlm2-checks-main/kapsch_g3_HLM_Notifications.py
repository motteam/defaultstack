#!/usr/bin/python3
import requests, os, json
import ami_go_authorization_aus_glide_pb2
import kapsch_g3_hlm_status_pb2
import kapsch_g3_hlm_alerts_pb2
import kapsch_g3_hlm_notifications_pb2
from google.protobuf import json_format
import urllib3
import configparser
import argparse
#import ic

def ReadConfigurationGeneral():
    # read data from config
    config = configparser.ConfigParser()
    config.read('kapsch_g3_HLM_config.ini')

    EDIS_IP = config.get("default", "EDIS_IP")
    API_Key = config.get("default", "API_Key")

    #EDIS_IP='10.24.3.245' #WGTP
    #EDIS_IP='192.168.100.10' #Simulator
    #API_Key = "2e3f77e0-364d-49f8-a734-4ac6dcfbf263"
    #API_Key = "ApiKey-Hlm"

    Configuration = {"EDIS_IP": EDIS_IP, "API_Key": API_Key}

    return Configuration


def ReadArguments():
    # Parser
    parser = argparse.ArgumentParser()
    parser.add_argument('-do', '--tollingDomain', required=True, help="Tolling Domain", type=int)
    parser.add_argument('-tp', '--tollingPoint', required=True, help="Tolling Point", type=int)
    parser.add_argument('-ts', '--tollingSegment', required=True, help="Tolling Segment", type=int)
    parser.add_argument('-in', '--tollingInstance', required=True, help="Tolling Instance", type=int)
    parser.add_argument('-de', '--Device', required=True, help="Device like TSMC, TSC", type=str)

    Args = parser.parse_args()
    arguments = {"tollingDomain": Args.tollingDomain, "tollingPoint": Args.tollingPoint, "tollingSegment": Args.tollingSegment,
                 "tollingInstance": Args.tollingInstance, "Device": Args.Device}

    #arguments = {'tollingDomain': 2, 'tollingPoint': 2, 'tollingInstance': 1, 'tollingSegment': 2, 'Device': 'ALC'}

    return arguments


cwd = os.path.dirname(os.sys.argv[0])
os.chdir(cwd)

ConfigurationGeneral = ReadConfigurationGeneral()
EDIS_IP= ConfigurationGeneral["EDIS_IP"]
API_Key = ConfigurationGeneral["API_Key"]

Source = ReadArguments()
Device = Source["Device"]
Instance = Source["tollingInstance"]

#Remove Device for dictionary comparison in noitification
Source.pop("Device")

#Remove TollingSegmentID for dictionary comparison in noitification (some devices not )
if Device == "TSMC":
    Source.pop("tollingSegment")

if Instance == 0:
    Source.pop("tollingInstance")

#disable https warnings
urllib3.disable_warnings()

#Token + authorization
EDIS_authorization = 'https://'+EDIS_IP+':8766/api/users/authenticate'
headers = {'content-type':'text/plain'}


token_response = requests.post(EDIS_authorization, data=API_Key,headers=headers,verify=False)
#print (token_response)
auth=ami_go_authorization_aus_glide_pb2.Container()
auth.ParseFromString(token_response.content)
auth_token = auth.user.token
headers = {'Authorization': f'Bearer {auth_token}'}
#print(headers)


################################################################################################
# Notifications
################################################################################################

notifications_status_url='https://'+EDIS_IP+':8766/api/notifications/current'


#Getting Notifications
notifications_response = requests.get(notifications_status_url, headers=headers,verify=False)
notifications_response_container = kapsch_g3_hlm_notifications_pb2.Container()

try:
    #Converting to Python Dictonary
    notifications_response_container.ParseFromString(notifications_response.content)
    #print(notifications_response_container)
    notifications_status_dict = json_format.MessageToDict(notifications_response_container)
    #print(notifications_status_dict)

    alarm=''
    severity=set()
    for notification in notifications_status_dict['notificationList']['notifications']:
        #print(notification)
        if notification['sourceId']==Source and notification['node']==Device:
            alarm=alarm+notification['severity']+' : '+ notification['name']+'/'+ notification['notificationType']+' - '+notification['state']+'\n'
            severity.add(notification['severity'])
except Exception as e:
    severity='ERROR RETRIEVING DATA - ' + repr(e)


#Plugin Return Code	Service State
#0	OK
#1	WARNING
#2	CRITICAL
#3	UNKNOWN

if alarm=='':
    alarm='No Alarms have been detected'

#print(alarm)
#if 'SEVERITY_TYPE_ERROR' in severity or 'SEVERITY_TYPE_FATAL' in severity:
#    print(2) #Critical
#elif 'SEVERITY_TYPE_INFORMATION' in severity or 'SEVERITY_TYPE_WARNING' in severity:
#    print(1) #Warning
#else:
#    print(0) #OK

returnValue = 0

### Icinga
if 'SEVERITY_TYPE_ERROR' in severity or 'SEVERITY_TYPE_FATAL' in severity:
    returnValue = 2 #Critical
    print("High Level Message: " + alarm)
elif 'SEVERITY_TYPE_INFORMATION' in severity or 'SEVERITY_TYPE_WARNING' in severity:
    returnValue = 1 #Warning
    print("High Level Message: " + alarm)
elif '' == severity:
    returnValue = 3 #Unknown
    print("High Level Message: Service Does not Exist")
elif 'ERROR RETRIEVING DATA' in severity:
#    returnValue = 1 #Warning
    returnValue = 0 #ΟΚ
#    print("High Level Message: Error in retrieving data")
    print("High Level Message: The Notification List is Empty")
else:
    returnValue = 0 #OK
    print("High Level Message: " + alarm)

exit(returnValue)

