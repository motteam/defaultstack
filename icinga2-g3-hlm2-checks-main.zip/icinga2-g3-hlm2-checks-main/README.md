# icinga2-g3-hlm2-checks

## Abstract

The G3 platform ships with its own status and monitoring tool: The Tolling Monitor (TOMO). It also ships with a Hign Level Monitoring Interface - HLM2. These Icinga checks leverage HLM2 which exposes the information using a REST API inteface.

## Reference Documents

- HLM 2 Documentation: https://confluence.kapsch.net/x/hGlgG
- TOMO - Manual (incl. HLM Status/Alert Configuration): https://confluence.kapsch.net/x/64IyEg


## Description

The G3 Roadside System contains distributed instances of the G3 MLFF Roadside at each Tolling Point, which are all connected to the centralized G3 MLFF Tools. G3 MLFF Tools comes with a data concentration mechanism. Its main function is to gather data and expose it in a way that provides reactive and proactive Event Management. The target is to leverage this functionality through the HLM2 interface which provides a WebAPI to access Status and Alert information.

- G3 Server Services
- G3 RSS Services
- G3 Refined Status per Tolling Segment (Total)
- G3 Status Per Tolling Segment (Per Category, e.g. OBU, Vehicle, etc.)

## Setup and Configuration

/ [Install:: Pre-requisites](/Docs/Install%20prerequisites.adoc)  
/ [Monitor:: Data Center Services](/Docs/Monitor%20Data%20Center%20Services.adoc)  
/ [Monitor:: Devices](/Docs/Monitor%20Devices.adoc)  
/ [Monitor:: Tolling Segments](/Docs/Monitor%20Tolling%20Segments.adoc)  

## Installation
This implementation has been tested on RHEL 8.x but it should also work on RHEL 9.x installations. You will need a fully working Icinga2 instance with IcingaWeb2 and the Director installed. Upon that you will need to clone all developed scripts to the default nagios plugins location.

/ RHEL: /usr/lib64/nagios/plugins  
/ Ubuntu: /usr/lib/nagios/plugins

