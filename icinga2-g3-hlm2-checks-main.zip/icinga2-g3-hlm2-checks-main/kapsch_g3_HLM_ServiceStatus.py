#!/usr/bin/python3
import requests, os, json
import ami_go_authorization_aus_glide_pb2
import kapsch_g3_hlm_status_pb2
import kapsch_g3_hlm_alerts_pb2
import kapsch_g3_hlm_notifications_pb2
from google.protobuf import json_format
import urllib3
import configparser
import argparse
#import ic

def ReadConfigurationGeneral():
    # read data from config
    config = configparser.ConfigParser()
    config.read('kapsch_g3_HLM_config.ini')

    EDIS_IP = config.get("default", "EDIS_IP")
    API_Key = config.get("default", "API_Key")

    Configuration = {"EDIS_IP": EDIS_IP, "API_Key": API_Key}

    return Configuration


def ReadArguments():
    # Parser
    parser = argparse.ArgumentParser()
    parser.add_argument('-sn', '--serviceName', required=True, help="Service Name", type=str)

    Args = parser.parse_args()
    arguments = {"serviceName": Args.serviceName}

    #source_name: "Mlff Tools Log Collection"
    #source_name: "OMAD Backup"
    #source_name: "Rss Log Collection"
    #source_name: "Configuration Service"
    #source_name: "ETCS Data Interface Service"
    #source_name: "Collect and Evaluate Service"

    #arguments = {'serviceName': "Configuration Service"}

    return arguments


cwd = os.path.dirname(os.sys.argv[0])
os.chdir(cwd)

ConfigurationGeneral = ReadConfigurationGeneral()
EDIS_IP= ConfigurationGeneral["EDIS_IP"]
API_Key = ConfigurationGeneral["API_Key"]

Source = ReadArguments()

#disable https warnings
urllib3.disable_warnings()

#Token + authorization
EDIS_authorization = 'https://'+EDIS_IP+':8766/api/users/authenticate'
headers = {'content-type':'text/plain'}


token_response = requests.post(EDIS_authorization, data=API_Key,headers=headers,verify=False)
#print (token_response)
auth=ami_go_authorization_aus_glide_pb2.Container()
auth.ParseFromString(token_response.content)
auth_token = auth.user.token
headers = {'Authorization': f'Bearer {auth_token}'}
#print(headers)


################################################################################################
# Service Status
################################################################################################

service_status_url='https://'+EDIS_IP+':8766/api/status/services/current'

#Reading response
service_response = requests.get(service_status_url, headers=headers,verify=False)
service_response_container = kapsch_g3_hlm_status_pb2.Container()

try:
    #Saving to Json
    service_response_container.ParseFromString(service_response.content)
    #print(service_response_container)
    service_status_dict = json_format.MessageToDict(service_response_container)
    #print(service_status_dict)

    severity=''
    for service_status in service_status_dict['serviceStatusList']["serviceStatus"]:
        #print(notification)
        if service_status['sourceName'] == Source["serviceName"]:
            severity = service_status['status']
except Exception as e:
    severity='ERROR RETRIEVING DATA - ' + repr(e)


#Plugin Return Code	Service State
#0	OK
#1	WARNING
#2	CRITICAL
#3	UNKNOWN


### Icinga
if 'STATUS_TYPE_ERROR' == severity or 'STATUS_TYPE_FATAL' == severity:
    returnValue = 2 #Critical
    print("High Level Message: " + severity)
elif 'STATUS_TYPE_INFORMATION' == severity or 'STATUS_TYPE_WARNING' == severity:
    returnValue = 1 #Warning
    print("High Level Message: " + severity)
elif '' == severity:
    returnValue = 3 #Unknown
    print("High Level Message: Service Does not Exist")
elif 'ERROR RETRIEVING DATA' in severity:
    returnValue = 1 #Warning
    print("High Level Message: Error in retrieving data")
else:
    returnValue = 0 #OK
    print("High Level Message: " + severity)

#print("High Level Message: " + severity)
exit(returnValue)


