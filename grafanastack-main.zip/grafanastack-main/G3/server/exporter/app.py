import logging
import os
import time
from threading import Lock

import requests

from flask import Flask, Response

from prometheus_client import (
    Gauge,
    Counter,
    generate_latest,
    CONTENT_TYPE_LATEST
)

# --------------------------------------------------
# Flask App
# --------------------------------------------------

app = Flask(__name__)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s"
)

# --------------------------------------------------
# Configuration
# --------------------------------------------------

BASE_URL = os.environ["BASE_URL"]
API_KEY = os.environ["API_KEY"]

VERIFY_TLS = os.getenv(
    "VERIFY_TLS",
    "true"
).lower() == "true"

CA_CERT = os.getenv("CA_CERT")

CACHE_SECONDS = int(
    os.getenv("CACHE_SECONDS", "10")
)

AUTH_URL = f"{BASE_URL}/api/users/authenticate"
NOTIFICATION_URL = f"{BASE_URL}/api/notifications/current"

VERIFY_SETTING = (
    CA_CERT
    if CA_CERT
    else VERIFY_TLS
)

# --------------------------------------------------
# Globals
# --------------------------------------------------

session = requests.Session()

auth_token = None
last_update = 0

refresh_lock = Lock()

# --------------------------------------------------
# Exporter Metrics
# --------------------------------------------------

exporter_last_success_timestamp = Gauge(
    "exporter_last_success_timestamp",
    "Last successful API poll timestamp"
)

exporter_api_duration_seconds = Gauge(
    "exporter_api_duration_seconds",
    "API response time in seconds"
)

exporter_scrape_errors_total = Counter(
    "exporter_scrape_errors_total",
    "Exporter scrape failures"
)

exporter_auth_success_total = Counter(
    "exporter_auth_success_total",
    "Successful authentications"
)

exporter_auth_failures_total = Counter(
    "exporter_auth_failures_total",
    "Failed authentications"
)

# --------------------------------------------------
# Notification Metrics
# --------------------------------------------------

notification_gauge = Gauge(
    "tolling_notifications",
    "Active tolling notifications",
    [
        "domain",
        "point",
        "segment",
        "instance",
        "node",
        "name",
        "severity"
    ]
)

active_notifications_total = Gauge(
    "tolling_active_notifications_total",
    "Total active notifications"
)

# --------------------------------------------------
# Authentication
# --------------------------------------------------

def authenticate():

    global auth_token

    try:

        logging.info(
            "Authenticating with notification API"
        )

        response = session.post(
            AUTH_URL,
            headers={
                "Content-Type": "text/plain",
                "Accept": "application/json"
            },
            data=API_KEY,
            timeout=10,
            verify=VERIFY_SETTING
        )

        response.raise_for_status()

        auth_token = (
            response.json()["user"]["token"]
        )

        exporter_auth_success_total.inc()

        logging.info(
            "Authentication successful"
        )

    except Exception:

        exporter_auth_failures_total.inc()

        logging.exception(
            "Authentication failed"
        )

        raise

# --------------------------------------------------
# Fetch Notifications
# --------------------------------------------------

def fetch_notifications():

    global auth_token

    if auth_token is None:
        authenticate()

    start = time.time()

    response = session.get(
        NOTIFICATION_URL,
        headers={
            "Authorization": (
                f"Bearer {auth_token}"
            ),
            "Accept": "application/json"
        },
        timeout=10,
        verify=VERIFY_SETTING
    )

    if response.status_code == 401:

        logging.warning(
            "Token expired, re-authenticating"
        )

        authenticate()

        response = session.get(
            NOTIFICATION_URL,
            headers={
                "Authorization": (
                    f"Bearer {auth_token}"
                ),
                "Accept": "application/json"
            },
            timeout=10,
            verify=VERIFY_SETTING
        )

    response.raise_for_status()

    exporter_api_duration_seconds.set(
        time.time() - start
    )

    return response.json()

# --------------------------------------------------
# Refresh Metrics
# --------------------------------------------------

def refresh_metrics():

    global last_update

    with refresh_lock:

        now = time.time()

        if (
            now - last_update
            < CACHE_SECONDS
        ):
            return

        data = fetch_notifications()

        notifications = (
            data
            .get("notificationList", {})
            .get("notifications", [])
        )

        notification_gauge.clear()

        grouped = {}

        for notification in notifications:

            source = notification.get(
                "sourceId",
                {}
            )

            key = (
                str(
                    source.get(
                        "tollingDomain",
                        0
                    )
                ),
                str(
                    source.get(
                        "tollingPoint",
                        0
                    )
                ),
                str(
                    source.get(
                        "tollingSegment",
                        0
                    )
                ),
                str(
                    source.get(
                        "tollingInstance",
                        0
                    )
                ),
                str(
                    notification.get(
                        "node",
                        "unknown"
                    )
                ),
                str(
                    notification.get(
                        "name",
                        "unknown"
                    )
                ),
                str(
                    notification.get(
                        "severity",
                        0
                    )
                )
            )

            grouped[key] = (
                grouped.get(key, 0) + 1
            )

        for labels, count in grouped.items():

            notification_gauge.labels(
                *labels
            ).set(count)

        active_notifications_total.set(
            len(notifications)
        )

        exporter_last_success_timestamp.set(
            time.time()
        )

        last_update = now

        logging.info(
            "Processed %s notifications",
            len(notifications)
        )

# --------------------------------------------------
# Health Endpoint
# --------------------------------------------------

@app.route("/healthz")
def healthz():

    return {
        "status": "ok"
    }

# --------------------------------------------------
# Metrics Endpoint
# --------------------------------------------------

@app.route("/metrics")
def metrics():

    try:

        refresh_metrics()

    except Exception as e:

        exporter_scrape_errors_total.inc()

        logging.exception(
            "Exporter scrape failed"
        )

        return Response(
            str(e),
            status=500
        )

    return Response(
        generate_latest(),
        mimetype=CONTENT_TYPE_LATEST
    )

# --------------------------------------------------
# Main
# --------------------------------------------------

if __name__ == "__main__":

    app.run(
        host="0.0.0.0",
        port=8000
    )