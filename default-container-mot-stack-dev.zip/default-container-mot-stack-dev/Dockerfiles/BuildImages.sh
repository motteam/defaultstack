cd grafana
docker build -t grafanav0.2 .
cd ..
cd icinga
docker build -t icingav0.2 .
cd ..
cd icingadb
docker build -t icingadbv0.2 .
cd ..
cd icingaweb
docker build -t icingawebv0.2 .
cd ..
cd influxdb
docker build -t influxdbv0.2 .
cd ..
cd mariadb
docker build -t mariadbv0.2 .
cd ..
cd prometheus
docker build -t prometheusv0.2 .
cd ..
cd redis
docker build -t redisv0.2 .