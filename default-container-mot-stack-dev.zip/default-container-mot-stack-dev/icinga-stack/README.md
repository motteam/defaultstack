Default Monitoring Stack  - Docker Containers


##RUN
docker-compose -f mstack.yml -p icinga up -d

##To make changes to the Stack: Bring Down and Keep Volumes
docker-compose -p icinga down

Role of main components:

1. Icinga2 - Events Management Collector - Frontend Monitoring:

    a. Collects incoming events sent out from IP Devices (Datacenter/Roadside)
    b. When Norm/Threshold is breached, notification is sent out to Alarm Concentrator
    c. Events are sent out based on Criticality

    Backend:
        a. MariaDB - Relational DB for Event aggregation
        b. InfluxDB - TimeSeries DB for monitoring of IOT data trends / alerting on specific events and help visualize directions 

2. Prometheus / Grafana - Dashboard visualization of Data - Observability:
    a. Series of events can be visualized in dashboards
    b. Historical data events - visualized in Graphs



