#!/bin/sh -x
influx -execute 'CREATE DATABASE icinga'
influx -execute 'SHOW DATABASES'
influx -database 'icinga' -execute 'CREATE USER icinga WITH PASSWORD '\'icinga\'' WITH ALL PRIVILEGES'
influx -execute 'show retention policies on "icinga"'
influx -execute 'create retention policy "icinga_2_weeks" on "icinga" duration 2w replication 1 default'
influx -execute 'alter retention policy "icinga_2_weeks" on "icinga" default'
influx -execute 'drop retention policy "autogen" on "icinga"'
