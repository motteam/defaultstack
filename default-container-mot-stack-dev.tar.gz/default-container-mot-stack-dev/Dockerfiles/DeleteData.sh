#!/bin/bash
#Delete persistent data in the /data directory for testing purposes only

cd /data/grafana
rm -rf *
cd /data/icinga
rm -rf *
cd /data/icingaweb
rm -rf *
cd /data/mysql
rm -rf *
cd /data/prometheus
rm -rf *